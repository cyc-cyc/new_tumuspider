from scrapy import cmdline
import pandas as pd
import time
import sys
import os
import json
from selenium.webdriver.remote.remote_connection import LOGGER
import logging
LOGGER.setLevel(logging.DEBUG)  # 启用调试日志
import subprocess
import sys
import os 
import argparse
def run_command_in_conda_env(env_name, command_to_run):
    """
    Executes a command in a specified conda environment.
    
    Args:
    - env_name: str, the name of the conda environment to activate.
    - command_to_run: list, the command to run along with its arguments.
    
    Returns:
    - None, but prints the command output or error.
    """
    # Construct the conda command
    try:
        # Ensure the arguments are correctly passed to the script
        command = ['conda', 'run', '-n', env_name] + command_to_run
        
        # Run the command in a shell subprocess
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # Capture the standard output and error
        stdout, stderr = process.communicate()
        
        # Check if the process was successful
        if process.returncode == 0:
            print(stdout.decode())
        else:
            print(f"Error occurred: {stderr.decode()}", file=sys.stderr)
    except Exception as e:
        print(f"An error occurred while executing the command: {e}", file=sys.stderr)

if __name__ == "__main__":
    if len(sys.argv) > 3:
        building_name = sys.argv[1]
        id = sys.argv[2]
        root = sys.argv[3]

    # command_to_run = ['python', 'chrome_search.py', building_name]  
    # env_name="spider"
    # run_command_in_conda_env(env_name, command_to_run)
    
    # 将 URL 列表转为字符串，用逗号分隔
    # 读取 JSON 文件

    # urls_str = ",".join(links)
    cmdline.execute(f'scrapy crawl wikipieda_spider -a building_name={building_name.replace(" ","")} -a id={str(id)} -a root={str(root)}'.split())
