import json
import os
import sys

# 定义键名映射
key_mapping = {
    "对象ID": "unionId",
    "爬取时间": "dataTime",  # 这里需要注意，原字段是爬取时间，与需求字段数据时间不完全对应
    "对象类型": "objectType",
    "建筑名称": "objectName",  # 这里需要注意，原字段是建筑名称，与需求字段对象名称不完全对应
    "对象地址": "objectAddress",
    "建筑功能": "buildingFunction",
    "地理坐标": "geographicCoordinates",
    "所处行政区/地理区划": "administrativeRegion",
    "建造年代": "constructionYear",
    "结构形式": "structuralForm",
    "建造材料": "constructionMaterial",
    "建筑/桥梁平面尺寸": "planeSize",
    "建筑高度": "buildingHeight",
    "建筑层数": "numOfFloors",
    "土质条件": "soilCondition",
    "地上/地下层数": "numOfAboveUnderFloor",
    "基础形式": "foundationForm",
    "使用规范": "usageStandard",
    "隧道断面类型": "crossSectionType",
    "围岩等级": "rockGrade",
    "车道数": "numOfLanes",
    # 其他字段映射
}

def replace_keys(data, mapping):
    result = []
    for item in data:
        new_item = {}
        for old_key, new_key in mapping.items():
            # 如果值为空字符串，则替换为 None
            value = item.get(old_key, "")
            new_item[new_key] = None if value == "" else value
        result.append(new_item)
    return result


if __name__ == "__main__":
    if len(sys.argv) > 1:
        root = sys.argv[1]
    # 指定文件路径
    input_file_path = root+'/show//final.json'  # 输入文件路径

    # 读取 JSON 文件
    with open(input_file_path, 'r', encoding='utf-8') as infile:
        data = json.load(infile)

    # 替换键名并确保所有字段存在
    processed_data = replace_keys(data, key_mapping)

    # 生成输出文件路径
    base_name, _ = os.path.splitext(input_file_path)
    output_file_path = f"{base_name}_replace_key.json"

    # 将结果写入新文件
    with open(output_file_path, 'w', encoding='utf-8') as outfile:
        json.dump(processed_data, outfile, ensure_ascii=False, indent=4)

    print(f"处理完成，结果已保存至 {output_file_path}")