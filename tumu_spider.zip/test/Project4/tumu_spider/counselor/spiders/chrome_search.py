import pandas as pd
import time
import sys
import json
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException
import time


def search_rakuya_urls(buliding_name, num_pages=5, retries=3):
    """
    启动 WebDriver，打开指定的 URL，并提取页面中符合条件的链接，处理异常情况。
    
    参数:
    - buliding_name (str): 需要搜索的建筑名称。
    - num_pages (int): 限制返回的最大链接数，默认为 1。
    - retries (int): 最大重试次数，默认为 3。

    返回:
    - list: 提取的链接列表，出现异常时返回空列表。
    """
    # 定义搜索区域的 regionId 列表
    keys = ["sell","land"]
    region_ids = [2,0]
    base_url = "https://www.rakuya.com.tw/{}/result?city={}&keyword={}"  # 基础 URL 模板
    all_links=[]
    # 设置 WebDriver 配置
    options = webdriver.ChromeOptions()
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-software-rasterizer")  # 禁用软件渲染
    options.add_argument("--headless")  # 启用无头模式（如果在无图形界面的环境中运行）
    # options.add_argument("--no-proxy-server")  # 禁用代理
    options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")
    for key in keys:
        for region_id in region_ids:
            url = base_url.format(key,region_id,buliding_name) 
            retries_left = retries  # 每个区域的重试次数

            while retries_left > 0:
                driver = None  # 初始化 driver 为 None，防止未成功创建时调用 quit()
                try:
                    print(f"正在尝试抓取区域 {region_id}，URL: {url}")
                    driver = webdriver.Chrome(options=options)  # 在循环里启动 WebDriver

                    driver.get(url)
                    # print(driver.current_url)  # 获取当前 URL
                    # if "postType" in driver.current_url:
                    #     pass
                    # else:
                    #     all_links.append(driver.current_url)  # 添加到列表中
                    # 等待包含目标链接的元素可见
                    if "land" in url:
                        results = WebDriverWait(driver, 20).until(
                            EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'a[class="browseItemDetail"]'))  # 根据实际链接选择器
                        )
                    else:
                        results = WebDriverWait(driver, 20).until(
                            EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'a[target="_blank"]'))  # 根据实际链接选择器
                        )

                    # 提取并保存链接
                    links = [result.get_attribute('href') for result in results]
                    useful_links = [link for link in links if link and ('/buy/house/' in link or 'sell_item' in link) and not "null" in link]  # 筛选有效链接
                    
                    useful_links = useful_links[:num_pages]  # 限制返回的结果数量
                    all_links.extend(useful_links)  # 将结果添加到总列表中

                    # 成功后跳出重试循环
                    break

                except TimeoutException:
                    print(f"页面加载超时: {url}")
                    retries_left -= 1
                    if retries_left == 0:
                        print(f"多次尝试加载页面失败，跳过该区域: {url}")
                except Exception as e:
                    print(f"抓取链接时出现异常: {e}")
                    retries_left -= 1
                    if retries_left == 0:
                        print(f"多次抓取失败，跳过该区域: {url}")
                    else:
                        time.sleep(2)  # 等待 2 秒后再尝试
                finally:
                    # 只有在 driver 成功创建时才调用 quit()
                    if driver is not None:
                        driver.quit()

    return all_links  # 返回所有抓取到的链接


def search_sinyi_urls(buliding_name, num_pages=5, retries=3):
    """
    启动 WebDriver，打开指定的 URL，并提取页面中符合条件的链接，处理异常情况。
    
    参数:
    - buliding_name (str): 需要搜索的建筑名称。
    - num_pages (int): 限制返回的最大链接数，默认为 1。
    - retries (int): 最大重试次数，默认为 3。

    返回:
    - list: 提取的链接列表，出现异常时返回空列表。
    """
    # 定义搜索区域的 regionId 列表
    keys = ["buy","rent"]

    region_ids = ["NewTaipei-city","Taipei-city"]
    base_url = "https://www.sinyi.com.tw/{}/list/{}-keyword/{}/"  # 基础 URL 模板
    all_links=[]

    # 设置 WebDriver 配置
    options = webdriver.ChromeOptions()
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-software-rasterizer")  # 禁用软件渲染
    options.add_argument("--headless")  # 启用无头模式（如果在无图形界面的环境中运行）
    # options.add_argument("--no-proxy-server")  # 禁用代理
    options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")
    for key in keys:
        for region_id in region_ids:
            url = base_url.format(key,buliding_name,region_id) 
            retries_left = retries  # 每个区域的重试次数

            while retries_left > 0:
                driver = None  # 初始化 driver 为 None，防止未成功创建时调用 quit()
                try:
                    print(f"正在尝试抓取区域 {region_id}，URL: {url}")
                    driver = webdriver.Chrome(options=options)  # 在循环里启动 WebDriver

                    driver.get(url)
                    # print(driver.current_url)  # 获取当前 URL
                    # if "postType" in driver.current_url:
                    #     pass
                    # else:
                    #     all_links.append(driver.current_url)  # 添加到列表中
                    # 等待包含目标链接的元素可见
                    results = WebDriverWait(driver, 20).until(
                        EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'a[target="_blank"]'))  # 根据实际链接选择器
                    )

                    # 提取并保存链接
                    links = [result.get_attribute('href') for result in results]
                    useful_links = [link for link in links if link and ('/buy/house/' in link or 'rent' in link) and not "null" in link]  # 筛选有效链接
                    
                    useful_links = useful_links[:num_pages]  # 限制返回的结果数量
                    all_links.extend(useful_links)  # 将结果添加到总列表中

                    # 成功后跳出重试循环
                    break

                except TimeoutException:
                    print(f"页面加载超时: {url}")
                    retries_left -= 1
                    if retries_left == 0:
                        print(f"多次尝试加载页面失败，跳过该区域: {url}")
                except Exception as e:
                    print(f"抓取链接时出现异常: {e}")
                    retries_left -= 1
                    if retries_left == 0:
                        print(f"多次抓取失败，跳过该区域: {url}")
                    else:
                        time.sleep(2)  # 等待 2 秒后再尝试
                finally:
                    # 只有在 driver 成功创建时才调用 quit()
                    if driver is not None:
                        driver.quit()

    return all_links  # 返回所有抓取到的链接

if __name__ == "__main__":
    if len(sys.argv) > 1:
        building_name = sys.argv[1]

    links = search_rakuya_urls(building_name)
    print(links)
    # links = search_sinyi_urls(building_name)
    # print(links)
    

    # # 保存为 JSON 文件
    # with open('list.json', 'w') as f:
    #     json.dump(links, f)
