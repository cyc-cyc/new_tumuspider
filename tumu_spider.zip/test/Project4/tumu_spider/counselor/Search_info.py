import pandas as pd
import re
import sys
import os
from fuzzywuzzy import process

# 读取 CSV 数据
file_path = "/data/wufanghao/土木项目/贝壳_二手房成交房源_上海.csv"
df = pd.read_csv(file_path)

# 功能：根据输入查询词提取区县、地址
def extract_address_info(input_str):
    districts = [
        "黄浦", "徐汇", "长宁", "静安", "普陀", "闸北", "虹口", "杨浦", "闵行", "宝山", 
        "嘉定", "浦东", "金山", "松江", "青浦", "奉贤", "崇明", "临港", "南汇"
    ]
    district_pattern = "|".join(districts)
    pattern = rf"^(?P<province>上海市|上海)?(?P<district>({district_pattern})区?)?(?P<address>[\w\s]+)"
    match = re.match(pattern, input_str)

    if match:
        address_info = match.groupdict()
        district = address_info.get('district', '无区县信息')
        address = address_info.get('address', '无具体地址')
        return {
            "district": district,
            "address": address
        }
    else:
        return None

# 功能：从“小区名称”中找到最匹配的记录
def match_nearest_str(query, df, threshold):
    choices = df['小区名称'].tolist()
    best_match = process.extractOne(query, choices)

    if best_match and best_match[1] >= threshold:
        match_name = best_match[0]
        matched_row = df[df['小区名称'] == match_name].iloc[0]
        return matched_row
    else:
        return None

# 功能：搜索输入的字符串
def search_str(input_str):
    address_info = extract_address_info(input_str)
    if address_info:
        query = address_info['address']
        search_results = match_nearest_str(query, df, threshold=80)
        if search_results is not None:
            return search_results.to_dict()  # Convert to dictionary for easier saving
        else:
            return {"error": f"没有找到“{input_str}”的相关信息"}
    else:
        return {"error": f"没有找到“{input_str}”的相关信息"}

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python Search_info.py <building_name> <root_directory>")
        sys.exit(1)

    building_name = sys.argv[1]
    root_directory = sys.argv[2]

    search_results = search_str(building_name)

    # Save results to the specified directory
    output_file_path = os.path.join(root_directory, f"{building_name}.txt")
    os.makedirs(root_directory, exist_ok=True)

    with open(output_file_path, 'w', encoding='utf-8') as f:
        if 'error' in search_results:
            pass
        else:
            for key, value in search_results.items():
                f.write(f"{key}: {value}\n")

