import pandas as pd
import json
import re
import os
def convert_year(year_str):
    # 优先匹配四位数年份
    match = re.search(r'(\d{4})年', year_str) 
    if match: 
        return int(match.group(1))
    # 使用正则表达式匹配字符串中最后一个'年'字之前的数字
    matches = re.findall(r'(\d+)年', year_str)
    if matches:
        # 提取匹配到的年份数字部分
        year_num_str = matches[-1]
        year_num = int(year_num_str)
        
        # 判断年份的位数，以确定是否为民国纪年法
        if len(year_num_str) == 3:
            # 将民国纪年法转换为公元纪年法
            return 1911 + year_num
        elif len(year_num_str) == 4:
            # 已是公元纪年法或非标准输入，直接返回
            return year_num
        else:
            return None
    else:
        # 未能从字符串中找到年份
        return None
    
    
# 定义键名映射
key_mapping = {
    "对象ID": "unionId",
    "爬取时间": "dataTime",  # 这里需要注意，原字段是爬取时间，与需求字段数据时间不完全对应
    "对象类型": "objectType",
    "建筑名称": "objectName",  # 这里需要注意，原字段是建筑名称，与需求字段对象名称不完全对应
    "对象地址": "objectAddress",
    "建筑功能": "buildingFunction",
    "地理坐标": "geographicCoordinates",
    "所处行政区/地理区划": "administrativeRegion",
    "建造年代": "constructionYear",
    "结构形式": "structuralForm",
    "建造材料": "constructionMaterial",
    "建筑/桥梁平面尺寸": "planeSize",
    "建筑高度": "buildingHeight",
    "建筑层数": "numOfFloors",
    "土质条件": "soilCondition",
    "地上/地下层数": "numOfAboveUnderFloor",
    "基础形式": "foundationForm",
    "使用规范": "usageStandard",
    "隧道断面类型": "crossSectionType",
    "围岩等级": "rockGrade",
    "车道数": "numOfLanes",
    # 其他字段映射
}

def replace_keys(data, mapping):
    result = []
    for item in data:
        new_item = {}
        for old_key, new_key in mapping.items():
            # 如果值为空字符串，则替换为 None
            value = item.get(old_key, "")
            new_item[new_key] = None if value == "" else value
        result.append(new_item)
    return result

'''
json_project2
[
    {
        "unionID": "1",
        "objectName": "國家世紀館B棟",
        "objectAddress": "101 Business Park, City Center",
        "numOfFloor": 29,
        "buildingHeight": 87,
        "buildingFunction": "Office",
        "constructionYear": -1,
        "structuralForm": "",
        "constructionMaterial": ""
    },
]
'''

'''
json_facade
[
    {
        "objectName": "捷運路61號",
        "constructionYear": "1970s"
    },
]
'''

'''
json_spider
中文的
xxx
'''
import re

def process_spider_year(text):
    # 年代存在冲突，怎么处理？作废
    if "存在冲突" in text:
        return 0
    else:
        numbers = re.findall(r'\d+', text)
        if numbers:
            max_number = max(map(int, numbers))
        return max_number

def process_spider_structuralForm(text):
    return text

def process_spider_constructionMaterial(text):
    if "RC" in text or "钢筋混凝土" in text or "钢筋" in text:
        return "ferroconcrete"
    elif "钢" in text:
        return "steel"
    else:
        return 0
    


def process_spider_function(text):
    # 这里字段可以重新搞一下，e.g.办公涉及哪些字段？
    if "办公" in text:
        return "Office"
    elif "学校" in text:
        return "School"
    elif "住宅" in text:
        return "Residential"
    elif "商场" in text:
        return "Mall"
    else:
        return text
    

def process_usageStandard(text):
    if "RC" in text or "钢筋混凝土" in text:
        return "钢筋混凝土结构设计规范"
    elif "钢" in text:
        return "钢筋结构设计规范"
    else:
        return text

# 从文件读取 JSON 数据
# 这里路径需要改
root = "/data/tumuTest/test"
with open(root + '/Project4/Facade/Temp/constructionYear.json', 'r', encoding='utf-8') as f1, \
     open(root +'/Project4/tumu_spider/Temp/show/final_replace_key.json', 'r', encoding='utf-8') as f2, \
     open(root +'/Project2/data.json', 'r', encoding='utf-8') as f3, \
     open(root +'/Project4/Structure/Temp/data.json', 'r', encoding='utf-8') as f4:
    json_facade = json.load(f1)
    json_spider = json.load(f2)
    json_project2 = json.load(f3)
    json_struct = json.load(f4)

# Input 年代，立面饰材，功能，层数，高度
# 年代：spider > facade
# 功能：project2 > spider
for building_f, building_s, building_p ,building_t in zip(json_facade, json_spider, json_project2,json_struct ):
    # 如果spider有年代，就用spider的年代替换facade的年代
    # 年代是字符串，xxxx年代，暂时改成10断代
    if building_s['constructionYear'] != "未提及":
        building_f['constructionYear'] = process_spider_year(building_s['constructionYear'])
        building_s['constructionYear'] = process_spider_year(building_s['constructionYear'])
    # 如果project2没有功能（空字符串“”），就用spider的功能补充project2的功能
    # Office，School，Presidential，Residential，Mall
    else:
        building_s['constructionYear'] = building_f['constructionYear']

    # building_s['对象ID'] == building_t['unionId']
    # if ['objectName']=="未提及" or 
    if building_s['constructionMaterial'] == "未提及" or  "存在冲突" in building_s['constructionMaterial']:
        building_s['constructionMaterial'] = building_t['constructionMaterial']
    elif process_spider_constructionMaterial(building_s['constructionMaterial']):
        building_s['constructionMaterial'] = process_spider_constructionMaterial(building_s['constructionMaterial'])
    else:
        building_s['constructionMaterial'] = building_t['constructionMaterial']

    if building_s['structuralForm'] == "未提及" or  "存在冲突" in building_s['structuralForm']:
        building_s['structuralForm'] = building_t['structuralForm']
    else:
        building_s['structuralForm'] = process_spider_structuralForm(building_s['structuralForm'])

    if building_s['buildingFunction']!='未提及':
        building_s['buildingFunction'] = process_spider_function(building_s['buildingFunction'])
    if building_s['usageStandard']!='未提及':
        building_s['usageStandard']=process_usageStandard(building_s['usageStandard'])


# 保存json_facade, json_project2到文件
# 这里路径需要改
with open(root + '/Project4/Facade/Temp/constructionYear.json', 'w', encoding='utf-8') as f1, \
     open(root + '/Project4/tumu_spider/Temp/data_structure.json', 'w', encoding='utf-8') as f3, \
     open(root + '/Project4/tumu_spider/Temp/merge.json', 'w', encoding='utf-8') as f5:
    json.dump(json_facade, f1, ensure_ascii=False, indent=4)
    json.dump(json_project2, f3, ensure_ascii=False, indent=4)
    json.dump(json_spider, f5, ensure_ascii=False, indent=4)

# 指定文件路径
input_file_path = root + '/Project4/tumu_spider/Temp/merge.json'  # 输入文件路径

# 读取 JSON 文件
with open(input_file_path, 'r', encoding='utf-8') as infile:
    data = json.load(infile)
try:
    data[-1]['对象ID']=str(id)
except:
    pass
# 替换键名并确保所有字段存在
processed_data = replace_keys(data, key_mapping)
# 生成输出文件路径
base_name, _ = os.path.splitext(input_file_path)
output_file_path = f"{base_name}_replace_key.json"

# 将结果写入新文件
with open(output_file_path, 'w', encoding='utf-8') as outfile:
    json.dump(processed_data, outfile, ensure_ascii=False, indent=4)

print(f"处理完成，结果已保存至 {output_file_path}")


import json

def merge_json_files(file1_path, file2_path, skeleton_path, output_path, use_file2=False):
    # 读取第一个 JSON 文件
    with open(file1_path, 'r', encoding='utf-8') as file1:
        json1 = json.load(file1)

    # 读取第二个 JSON 文件（如果需要）
    json2 = []
    if use_file2:
        with open(file2_path, 'r', encoding='utf-8') as file2:
            json2 = json.load(file2)

    # 读取 skeleton JSON 文件
    with open(skeleton_path, 'r', encoding='utf-8') as skeleton_file:
        skeleton_data = json.load(skeleton_file)

    # 创建一个合并字典
    merged_dict = {}

    # 合并逻辑
    for item in json1:
        if isinstance(item, dict):  # 确保 item 是字典
            union_id = item['unionId']
            item['skeleton'] = skeleton_data  # 添加 skeleton 字段
            merged_dict[union_id] = item

    if use_file2:
        for item in json2:
            if isinstance(item, dict):  # 确保 item 是字典
                union_id = item['unionId']
                item['skeleton'] = skeleton_data  # 添加 skeleton 字段

                if union_id in merged_dict:
                    # 检查每个字段，决定如何合并
                    for key in item.keys():
                        if key not in ['unionId', 'skeleton']:  # 忽略特定字段
                            if merged_dict[union_id].get(key) == '未提及':
                                merged_dict[union_id][key] = item[key]  # 以 file2_path 为准
                            elif merged_dict[union_id].get(key) == []:
                                merged_dict[union_id][key] = item[key]  # 以 file2_path 为准
                            elif merged_dict[union_id].get(key) is None and item[key] != []:
                                merged_dict[union_id][key] = item[key]  # 以 file2_path 为准
                else:
                    merged_dict[union_id] = item

    # 处理未提及和空列表的情况
    for union_id, item in merged_dict.items():
        for key in item.keys():
            if item[key] == '未提及' or item[key] == []:
                # 如果没有有效信息，则填入空列表
                merged_dict[union_id][key] = []

    # 转换回列表
    merged_list = list(merged_dict.values())

    # 如果合并后的列表为空，则填入空列表
    if not merged_list or all(all(v is None or v == [] for v in item.values()) for item in merged_list):
        merged_list = []

    # 将合并后的结果写入到目标文件
    with open(output_path, 'w', encoding='utf-8') as output_file:
        json.dump(merged_list, output_file, indent=4, ensure_ascii=False)

    print("数字化对象合并完成，结果已保存到", output_path)

# 示例调用
file1_path = '/data/tumuTest/test/Project4/tumu_spider/Temp/merge.json'
file2_path = '/data/tumuTest/test/Project2/data.json'
skeleton_path = '/data/tumuTest/test/Project4/StreetView/Skeleton/json/building_E121_486666_N25_008146.json'
output_path = '/data/tumuTest/test/Project4/data.json'

# 调用函数，选择是否合并
merge_json_files(file1_path, file2_path, skeleton_path, output_path, use_file2=True)